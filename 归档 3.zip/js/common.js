
$(function(){
     
      $(".x-show-control").click(function(){
        var menu_display="show";
        if($("body.x-hide").length>0){
          $("body").removeClass("x-hide");
        }else{
          $("body").addClass("x-hide");
          menu_display="hide";
        }
        if (window.localStorage) {
            localStorage.setItem("menu-display", menu_display);  
        } else {
            Cookie.write("menu-display", menu_display);  
        }
      })
    $(".x-menu>li>a").on("click",function(){
        if($(this).parent().find("ul")){
           !$(this).parent().hasClass("selected") && $(this).parent().parent().find("ul").slideUp();
          $(this).parent().find("ul").slideToggle();
          !$(this).parent().hasClass("selected") && $(this).parent().parent().find(".selected").removeClass("selected");
          $(this).parent().toggleClass("selected");
        }
    });
    $(".sub-menu>li>a").on("click",function(){
        !$(this).parent().hasClass("active") && $(".x-menu").find(".active").removeClass("active");
         $(this).parent().toggleClass("active");
    });
});
        
    